class Post < ActiveRecord::Base
    belongs_to :users
end